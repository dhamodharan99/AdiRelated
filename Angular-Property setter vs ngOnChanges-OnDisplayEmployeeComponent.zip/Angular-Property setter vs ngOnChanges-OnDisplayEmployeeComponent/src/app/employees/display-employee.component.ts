import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { Employee } from '../models/employee.model';
@Component({
  selector: 'appdisplayemployee',
  templateUrl: './display-employee.component.html',
  styleUrls: ['./display-employee.component.css']
})
export class DisplayEmployeeComponent implements OnInit {
  private _employee: Employee;
  // This Property Setter is called anytime the input property changes
  // Notice the code here logs the previous and current employee names
  @Input()
  set employee(val: Employee) {
    console.log('Previous : ' + (this._employee ? this._employee.name : 'NULL'));
    console.log('Current : ' + val.name);
    this._employee = val;
  }
  // This getter is called when reading and displaying data
  get employee(): Employee {
    return this._employee;
  }
  
  constructor() { }
  ngOnInit() {
  }
  //with ngOnChanges you have access to all input property changes at one place. But
  //Property setter is specific to a given property, so we only get changes of that specific property
  ngOnChanges(changes: SimpleChanges) {
      for (const propName of Object.keys(changes)) {
        const change = changes[propName];
        const from = JSON.stringify(change.previousValue);
        const to = JSON.stringify(change.currentValue);
        console.log(propName + ' changed from ' + from + ' to ' + to);
      }
    }
    // The above for loop in ngOnChanges is equalent to the following set of codes:
    //We need to track we need to write a separate property settes for the each one.
    //     private _employeeId: number;
    // @Input()
    // set employeeId(val: number) {
    //   console.log('employeeId changed from ' + JSON.stringify(this._employeeId)
    //     + ' to ' + JSON.stringify(val));
    //   this._employeeId = val;
    // }
    // get employeeId(): number {
    //   return this._employeeId;
    // }
    // private _employee: Employee;
    // @Input()
    // set employee(val: Employee) {
    //   console.log('employee changed from ' + JSON.stringify(this._employee)
    //     + ' to ' + JSON.stringify(val));
    //   this._employee = val;
    // }
    // get employee(): Employee {
    //   return this._employee;
    // }
}
